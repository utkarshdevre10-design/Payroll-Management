<?php include "config.php"; ?>
<!DOCTYPE html>
<html>
<head>
<title>Add Employee</title>
<style>
.success-box {
    border: 2px solid green;
    padding: 15px;
    margin-top: 20px;
    width: 350px;
    background: #e8ffe8;
    
}
/* ---- GLOBAL ---- */
body {
    font-family: Arial, Helvetica, sans-serif;
    background: #f4f7fa;
    margin: 0;
    padding: 20px;
}

/* ---- PAGE TITLE ---- */
h2 {
    text-align: center;
    color: #333;
    margin-bottom: 25px;
}

/* ---- FORM CONTAINER ---- */
form {
    width: 400px;
    margin: auto;
    background: #ffffff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}

/* ---- FORM LABELS ---- */
form label {
    font-weight: bold;
    display: block;
    margin-bottom: 6px;
    color: #444;
}

/* ---- INPUT FIELDS ---- */
input[type="text"],
input[type="date"],
select {
    width: 100%;
    padding: 10px;
    margin-bottom: 18px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
}

input[type="text"]:focus,
input[type="date"]:focus,
select:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0px 0px 3px rgba(0,123,255,0.5);
}

/* ---- SUBMIT BUTTON ---- */
input[type="submit"] {
    width: 100%;
    padding: 12px;
    background: #007bff;
    border: none;
    color: white;
    font-size: 16px;
    font-weight: bold;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.3s;
}

input[type="submit"]:hover {
    background: #0056b3;
}

/* ---- SUCCESS BOX ---- */
.success-box {
    border: 2px solid green;
    padding: 20px;
    margin: 25px auto;
    width: 400px;
    border-radius: 8px;
    background: #e8ffe8;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}

.success-box h3 {
    margin-top: 0;
    color: green;
}

/* ---- LOGIN LINK ---- */
a {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #007bff;
    font-weight: bold;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<h2>Add New Employee</h2>

<form method="post">
    Name: <input type="text" name="name" required><br><br>

    Department:
    <select name="dept_id" required>
        <option value="">-- Select Department --</option>
        <?php
        $dept_query = "SELECT * FROM department";
        $dept_result = mysqli_query($conn, $dept_query);
        while ($row = mysqli_fetch_assoc($dept_result)) {
            echo "<option value='{$row['dept_id']}'>{$row['dept_name']}</option>";
        }
        ?>
    </select>
    <br><br>

    Post:
    <select name="post_id" required>
        <option value="">-- Select Post --</option>
        <?php
        $post_query = "SELECT * FROM post";
        $post_result = mysqli_query($conn, $post_query);
        while ($row = mysqli_fetch_assoc($post_result)) {
            echo "<option value='{$row['post_id']}'>{$row['post_title']}</option>";
        }
        ?>
    </select>
    <br><br>

    Contact: <input type="text" name="contact"><br><br>
    DOJ: <input type="date" name="doj"><br><br>

    <input type="submit" name="save" value="Add Employee">
</form>

<?php

// ---------------------- BASIC PAY MATRIX ----------------------
$salary_matrix = [
    1 => [1 => 75000, 2 => 45000, 4 => 32000, 5 => 12000],
    2 => [1 => 70000, 3 => 40000, 4 => 30000, 5 => 10000],
    3 => [1 => 60000, 4 => 35000, 5 => 8000],
    4 => [1 => 50000, 3 => 30000, 4 => 28000, 5 => 7000],
    5 => [1 => 65000, 3 => 32000, 4 => 30000, 5 => 9000]
];

// ---------------------------------------------------------------


if (isset($_POST['save'])) {

    $name = $_POST['name'];
    $dept_id = $_POST['dept_id'];
    $post_id = $_POST['post_id'];
    $contact = $_POST['contact'];
    $doj = $_POST['doj'];

    // CHECK VALIDITY OF COMBINATION
    // CHECK VALIDITY OF COMBINATION
    if (!isset($salary_matrix[$dept_id][$post_id])) 
    {
        echo "<script>
                alert('⚠️ Invalid Department–Post combination! Please select the correct Post for this Department.');
                window.location.href = 'add_employee.php';
            </script>";
        exit;
    }

    else 
    {
        $basic = $salary_matrix[$dept_id][$post_id];
    }

    // Insert query
    $sql = "INSERT INTO employees (name, dept_id, post_id, contact, doj, basic_pay)
            VALUES ('$name', '$dept_id', '$post_id', '$contact', '$doj', '$basic')";

    if (mysqli_query($conn, $sql)) {

        // GET AUTO GENERATED emp_id
        $emp_id = mysqli_insert_id($conn);

        // FETCH department & post names
        $dept = mysqli_fetch_assoc(mysqli_query($conn, "SELECT dept_name FROM department WHERE dept_id=$dept_id"))['dept_name'];
        $post = mysqli_fetch_assoc(mysqli_query($conn, "SELECT post_title FROM post WHERE post_id=$post_id"))['post_title'];

        echo "
        <div class='success-box'>
            <h3>Employee Added Successfully!</h3>
            <p><b>Employee ID:</b> $emp_id</p>
            <p><b>Name:</b> $name</p>
            <p><b>Department:</b> $dept</p>
            <p><b>Post:</b> $post</p>
            <p><b>Contact:</b> $contact</p>
            <p><b>Date of Joining:</b> $doj</p>
            <p><b>Assigned Basic Pay:</b> ₹$basic</p>
            <hr>
            <p style='color:red;'><b>IMPORTANT:</b> Please note your Employee ID for future logins.</p>
        </div>
        ";
    } 
    else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<a href="login.php">Go to Login Page</a>
</body>
</html>

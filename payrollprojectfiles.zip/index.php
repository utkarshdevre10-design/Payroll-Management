<?php
include "config.php";
include "auth.php";

// If user not logged in → redirect to login
if (!isset($_SESSION['emp_id'])) {
    header("Location: login.php");
    exit;
}

$emp_id = $_SESSION['emp_id'];

// Get full employee details
$query = "
    SELECT e.*, d.dept_name, p.post_title
    FROM employees e
    JOIN department d ON e.dept_id = d.dept_id
    JOIN post p ON e.post_id = p.post_id
    WHERE e.emp_id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $emp_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$emp = mysqli_fetch_assoc($result);
$show_payroll = !empty($_SESSION['attendance_saved']);


?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard - Paper.Ltd</title>

<style>
body {
    margin: 0;
    font-family: Arial;
    background: #eef1f5;
}

.header {
    background: #0033aa;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 28px;
    font-weight: bold;
}

.emp-info {
    width: 450px;
    background: white;
    padding: 20px;
    margin: 25px auto;
    border-radius: 12px;
    box-shadow: 0 0 10px #a8b0c2;
}

.emp-info h2 {
    text-align: center;
}

label {
    font-weight: bold;
    color: #333;
}

.button-box {
    text-align: center;
    margin-top: 20px;
}

button, a.btn {
    display: inline-block;
    margin: 8px;
    padding: 12px 25px;
    background: #0077ff;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 6px;
    font-size: 15px;
    cursor: pointer;
}

button:hover, a.btn:hover {
    background: #005fcc;
}

.payroll-btn {
    background: green;
}
</style>

</head>
<body>

<div class="header">
    Paper.Ltd
</div>

<div class="emp-info">
    <h2>Welcome, <?= $emp['name'] ?></h2>
    <p><label>Employee ID:</label> <?= $emp['emp_id'] ?></p>
    <p><label>Department:</label> <?= $emp['dept_name'] ?></p>
    <p><label>Post:</label> <?= $emp['post_title'] ?></p>
    <p><label>Contact:</label> <?= $emp['contact'] ?></p>
    <p><label>Date of Joining:</label> <?= $emp['doj'] ?></p>
    <p><label>Basic Salary:</label> ₹<?= $emp['basic_pay'] ?></p>

    <div class="button-box">
        <a href="attendance.php" class="btn">Mark Attendance</a>
        <a href="update.php" class="btn">Update Data</a>
        <a href="delete.php" class="btn">Delete Data</a>
        <a href="employees.php" class="btn">List of Employees</a>
    </div>

    <?php if($show_payroll): ?>
    <div class="button-box">
        <a href="payroll.php" class="btn payroll-btn">Generate Payroll</a>
    </div>
    <?php endif; ?>
</div>
<?php unset($_SESSION['attendance_saved']); ?>
<div style="text-align:center; margin-top:20px;">
    <a href="logout.php" 
       style="
            background:#d9534f; 
            color:white; 
            padding:12px 25px; 
            text-decoration:none; 
            border-radius:6px; 
            font-size:15px;
            display:inline-block;
       ">
        Logout
    </a>
</div>

</body>
</html>

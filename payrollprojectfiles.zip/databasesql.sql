CREATE DATABASE IF NOT EXISTS payroll;
USE payroll;

-- ========================
-- 1) DEPARTMENT TABLE
-- ========================
CREATE TABLE department (
    dept_id INT(11) NOT NULL AUTO_INCREMENT,
    dept_name VARCHAR(100),
    PRIMARY KEY (dept_id)
);

-- ========================
-- 2) POST TABLE
-- ========================
CREATE TABLE post (
    post_id INT(11) NOT NULL AUTO_INCREMENT,
    dept_id INT(11) NOT NULL,
    post_title VARCHAR(100),
    PRIMARY KEY (post_id),
    KEY dept_fk (dept_id),
    CONSTRAINT post_ibfk_1 FOREIGN KEY (dept_id)
        REFERENCES department(dept_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ========================
-- 3) EMPLOYEES TABLE
-- ========================
CREATE TABLE employees (
    emp_id INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100),
    dept_id INT(11) NOT NULL,
    post_id INT(11) NOT NULL,
    contact VARCHAR(20),
    doj DATE,
    basic_pay DECIMAL(10,2),

    PRIMARY KEY(emp_id),

    KEY dept_fk (dept_id),
    KEY post_fk (post_id),

    CONSTRAINT emp_ibfk_1 FOREIGN KEY (dept_id)
        REFERENCES department(dept_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT emp_ibfk_2 FOREIGN KEY (post_id)
        REFERENCES post(post_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ========================
-- 4) ATTENDANCE TABLE
-- ========================
CREATE TABLE attendance (
    att_id INT(11) NOT NULL AUTO_INCREMENT,
    emp_id INT(11) NOT NULL,
    month_year VARCHAR(20),
    num_leaves INT(11),

    PRIMARY KEY(att_id),
    KEY emp_fk (emp_id),

    CONSTRAINT attendance_ibfk_1 FOREIGN KEY (emp_id)
        REFERENCES employees(emp_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ========================
-- 5) PAYROLL TABLE
-- ========================
CREATE TABLE payroll (
    pay_id INT(11) NOT NULL AUTO_INCREMENT,
    emp_id INT(11) NOT NULL,
    month_year VARCHAR(10),

    basic_pay DECIMAL(10,2),
    hra DECIMAL(10,2),
    medical DECIMAL(10,2),
    conveyance DECIMAL(10,2),
    pf DECIMAL(10,2),
    professional_tax DECIMAL(10,2),
    leave_deduction DECIMAL(10,2),

    gross_salary DECIMAL(10,2),
    total_deductions DECIMAL(10,2),
    net_salary DECIMAL(10,2),

    PRIMARY KEY(pay_id),
    KEY emp_fk (emp_id),

    CONSTRAINT payroll_ibfk_1 FOREIGN KEY(emp_id)
        REFERENCES employees(emp_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

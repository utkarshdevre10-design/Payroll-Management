<?php
include "config.php";
include "auth.php";

// Ensure session is active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$emp_id = $_SESSION['emp_id'];
$post_id = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT post_id FROM employees WHERE emp_id=$emp_id")
)['post_id'];


?>

<!DOCTYPE html>
<html>
<head>
<title>Employees</title>

<style>
body {
    font-family: Arial;
    text-align: center;
    background: #eef2f7;
    padding-top: 40px;
}

.container {
    width: 85%;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #b8c2d0;
}

h2 {
    margin-top: 0;
    color: #0077ff;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th {
    background: #0077ff;
    color: white;
    padding: 12px;
}

td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

tr:hover {
    background: #f1f5fb;
}

.error {
    color: red;
    font-size: 22px;
    margin-top: 40px;
}

.button-box {
    margin-top: 25px;
}

.btn {
    padding: 12px 25px;
    background: #0077ff;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    font-size: 16px;
}

.btn:hover {
    background: #005fcc;
}
</style>

</head>
<body>

<div class="container">

<?php
// ALLOWED VIEWERS → Manager (post_id=3) OR HR Executive (post_id=4)

if($post_id==1 ||$post_id==4)
{

     echo "<h2>Employee List</h2>";

    echo "<table>
            <tr>
                
                <th>Name</th>
                <th>Department</th>
                <th>Post</th>
                
            </tr>";

    $result = mysqli_query($conn,
        "SELECT e.name, d.dept_name, p.post_title  
         FROM employees e
         JOIN department d ON e.dept_id = d.dept_id
         JOIN post p ON e.post_id = p.post_id"
         
    );

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                
                <td>{$row['name']}</td>
                <td>{$row['dept_name']}</td>
                <td>{$row['post_title']}</td>
                
              </tr>";
    }

    echo "</table>";
}
else{
    echo "<p class='error'>❌ You are not eligible to view the employee list.</p>";
}
?>

<div class="button-box">
    <a href='index.php' class='btn'>Back to Home</a>
</div>

</div>

</body>
</html>

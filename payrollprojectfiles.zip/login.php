<?php
include "config.php";
include "auth.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $emp_id = trim($_POST['emp_id']);
    $name   = trim($_POST['name']);
    $dept   = trim($_POST['dept']);

    // Fetch employee record using mysqli
    $query = "
        SELECT e.*, d.dept_name
        FROM employees e
        JOIN department d ON e.dept_id = d.dept_id
        WHERE e.emp_id = ?
        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $emp_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $emp = mysqli_fetch_assoc($result);

    if ($emp) {

        // Normalize values (fix spaces & case)
        $db_name  = trim(strtolower($emp['name']));
        $in_name  = trim(strtolower($name));

        $db_dept  = trim(strtolower($emp['dept_name']));
        $in_dept  = trim(strtolower($dept));

        if ($db_name === $in_name && $db_dept === $in_dept) {

            // Login success → store in session
            $_SESSION['emp_id'] = $emp['emp_id'];
            $_SESSION['name']   = $emp['name'];
            $_SESSION['dept']   = $emp['dept_name'];

            echo "<script>
                    alert('Login Successful! Welcome, {$emp['name']}');
                    window.location.href = 'index.php';
                  </script>";
            exit;

        } else {
            $error = "❌ Incorrect login credentials. Try again.";
        }

    } else {
        $error = "❌ Incorrect login credentials. Try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Employee Login</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f0f4f8;
    padding-top: 60px;
    text-align: center;
}

.login-box {
    width: 400px;
    background: #fff;
    padding: 30px;
    margin:auto;
    border-radius: 10px;
    box-shadow: 0px 0px 10px #b7c2d0;
    text-align: left;
}

.login-box h2 {
    text-align: center;
    margin-bottom: 20px;
}

.login-box label {
    font-weight: bold;
}

.login-box input,
.login-box select {
    width: 100%;
    padding: 8px;
    margin: 8px 0 15px 0;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.login-box button {
    width: 100%;
    padding: 10px;
    background: #0077ff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 15px;
}

.login-box button:hover {
    background: #005fcc;
}

.error {
    color: red;
    margin-bottom: 10px;
    text-align: center;
}
/* Style for the A-tag */
.login-box a {
    color: #0077ff;
    text-decoration: none;
    font-weight: bold;
    display: inline-block;
}

.login-box a:hover {
    text-decoration: underline;
    color: #005fcc;
}


</style>

</head>
<body>

<div class="login-box">
    <h2>Employee Login</h2>

    <?php if(!empty($error)): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">

        <label>Employee ID:</label>
        <input type="number" name="emp_id" required>

        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Department:</label>
        <select name="dept" required>
            <option value="">-- Select Department --</option>
            <?php
            $dept_q = mysqli_query($conn, "SELECT dept_name FROM department");
            while ($d = mysqli_fetch_assoc($dept_q)) {
                echo "<option value='{$d['dept_name']}'>{$d['dept_name']}</option>";
            }
            ?>
        </select>

        <button type="submit">Login</button>
        <a href=add_employee.php style="float:right; margin-top:10px; font-size:14px;">New Employee? Add Here</a>
    </form>
</div>

</body>
</html>

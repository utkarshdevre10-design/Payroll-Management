<?php
include "config.php"; // mysqli connection: $conn
include "auth.php";
// If session not started, start it.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}



// FIND employee ID from various possible session keys
$empid = null;
if (isset($_SESSION['user']['empid'])) {
    $empid = $_SESSION['user']['empid'];
} elseif (isset($_SESSION['emp_id'])) {
    $empid = $_SESSION['emp_id'];
} elseif (isset($_SESSION['empid'])) {
    $empid = $_SESSION['empid'];
}

// If still not found → redirect
if (!$empid) {
    header("Location: login.php");
    exit;
}

$error = "";

// If user clicked delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm'])) {

    // 1️⃣ DELETE attendance first
    $sql1 = "DELETE FROM attendance WHERE emp_id = ?";
    $stmt1 = mysqli_prepare($conn, $sql1);
    mysqli_stmt_bind_param($stmt1, "i", $empid);
    mysqli_stmt_execute($stmt1);
    mysqli_stmt_close($stmt1);

    // 2️⃣ DELETE payroll records (if table exists)
    $sql2 = "DELETE FROM payroll WHERE emp_id = ?";
    if ($stmt2 = mysqli_prepare($conn, $sql2)) {
        mysqli_stmt_bind_param($stmt2, "i", $empid);
        mysqli_stmt_execute($stmt2);
        mysqli_stmt_close($stmt2);
    }

    // 3️⃣ DELETE employee record
    $sql3 = "DELETE FROM employees WHERE emp_id = ?";
    $stmt3 = mysqli_prepare($conn, $sql3);
    if ($stmt3) {
        mysqli_stmt_bind_param($stmt3, "i", $empid);

        if (mysqli_stmt_execute($stmt3)) {

            // DESTROY SESSION COMPLETELY
            $_SESSION = [];
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            session_destroy();

            // redirect to login
            // Redirect to success page
            header("Location: deleted_success.php");
            exit;


        } else {
            $error = "Delete failed: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt3);
    } else {
        $error = "Database error: Could not prepare DELETE statement.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Account</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f8d7da; }
        .box { background:white; padding:25px; width:380px; margin:40px auto; border-radius:8px; box-shadow:0 0 10px #aaa; }
        button { width:100%; padding:12px; border:none; font-size:16px; cursor:pointer; border-radius:5px; margin-top:10px; }
        .del { background:#d9534f; color:white; }
        .cancel { background:#5a6268; color:white; }
        .error { background:#ffe5e5; padding:12px; border-left:4px solid #d9534f; margin-bottom:12px; border-radius:6px; }
    </style>
</head>
<body>

<div class="box">
    <h2 style="color:#b20000;">⚠ Delete Account</h2>

    <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <p>Are you sure you want to permanently delete your account?</p>

    <form method="POST">
        <button class="del" name="confirm" onclick="deleted_success.php" >Yes, Delete My Account</button>
    </form>

    <a href="index.php"><button class="cancel">Cancel</button></a>
</div>

</body>
</html>

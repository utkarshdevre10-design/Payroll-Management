<?php
include "config.php";

// ------------------------------
// BASIC SALARY FUNCTION
// ------------------------------
function getBasicSalary($dept_id, $post_id) {
    $salary_matrix = [
        1 => [1 => 65000, 2 => 45000, 4 => 32000, 5 => 12000],
        2 => [1 => 62000, 3 => 40000, 4 => 30000, 5 => 10000],
        3 => [1 => 60000, 4 => 35000, 5 => 8000],
        4 => [1 => 50000, 3 => 30000, 4 => 28000, 5 => 7000],
        5 => [1 => 65000, 3 => 32000, 4 => 30000, 5 => 9000]
    ];
    return $salary_matrix[$dept_id][$post_id] ?? 0;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payroll Calculation</title>

<style>
/* SAME THEME AS ATTENDANCE PAGE */
body {
    font-family: Arial;
    text-align: center;
    background: #eef2f7;
    padding-top: 40px;
}

.box {
    width: 380px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #b8c2d0;
}

input, select {
    width: 90%;
    padding: 10px;
    margin: 12px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
}

button, a.btn {
    display: inline-block;
    margin: 10px;
    padding: 12px 22px;
    font-size: 16px;
    background: #0077ff;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    text-decoration: none;
}

button:hover, a.btn:hover {
    background: #005fcc;
}

.success { color: green; }
.error { color: red; }
</style>
</head>

<body>

<div class="box">
    <h2>Generate Payroll</h2>

    <form method="post">
        <label>Select Employee:</label><br>
        <select name="emp_id" required>
            <option value="">-- select --</option>
            <?php
            $emp = mysqli_query($conn, "SELECT * FROM employees");
            while ($e = mysqli_fetch_assoc($emp)) {
                echo "<option value='{$e['emp_id']}'>{$e['name']}</option>";
            }
            ?>
        </select>

        <label>Select Month:</label><br>
        <input type="month" name="month" required>

        <button type="submit" name="generate">Generate Payroll</button>
    </form>
</div>

<br><br>

<?php
if (isset($_POST['generate'])) {

    echo "<div class='box'>";

    $emp_id = $_POST['emp_id'];
    $month = $_POST['month'];

    // Prevent duplicate payroll entries
    $check = mysqli_query($conn, 
        "SELECT * FROM payroll WHERE emp_id='$emp_id' AND month_year='$month'");
    if (mysqli_num_rows($check) > 0) {
        echo "<h3 class='error'>Payroll for this employee & month is already generated.</h3>";
        echo "</div>";
        exit;
    }

    // Fetch employee details
    $emp = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT e.name, e.dept_id, e.post_id, d.dept_name, p.post_title
        FROM employees e
        JOIN department d ON e.dept_id = d.dept_id
        JOIN post p ON e.post_id = p.post_id
        WHERE e.emp_id = $emp_id"));

    $name = $emp['name'];
    $dept = $emp['dept_name'];
    $post = $emp['post_title'];

    $basic = getBasicSalary($emp['dept_id'], $emp['post_id']);

    // Leaves
    $att = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT num_leaves FROM attendance
         WHERE emp_id=$emp_id AND month_year='$month'"));

    $leaves = $att['num_leaves'] ?? 0;

    // ALLOWANCES
    $hra = $basic * 0.40;
    $medical = $basic * 0.10;
    $conveyance = $basic * 0.054;

    // DEDUCTIONS
    $pf = $basic * 0.095;
    $pt = $basic * 0.012;

    $unpaid = max(0, $leaves - 2);
    $leave_deduction = ($basic * 0.01) * $unpaid;

    // FINAL
    $gross = $basic + $hra + $medical + $conveyance;
    $total_deductions = $pf + $pt + $leave_deduction;
    $net_salary = $gross - $total_deductions;

    // INSERT INTO PAYROLL TABLE
    $insert = mysqli_query($conn, 
        "INSERT INTO payroll 
        (emp_id, month_year, basic_pay, hra, medical, conveyance, 
         pf, professional_tax, leave_deduction, 
         gross_salary, total_deductions, net_salary)
        VALUES 
        ('$emp_id', '$month', '$basic', '$hra', '$medical', '$conveyance',
         '$pf', '$pt', '$leave_deduction',
         '$gross', '$total_deductions', '$net_salary')"
    );

    if ($insert) {
        echo "<h3 class='success'>Payroll generated & saved successfully!</h3>";
    } else {
        echo "<h3 class='error'>Error saving payroll!</h3>";
    }

    echo "<h3>Payroll for $name ($month)</h3>";
    echo "Department: $dept <br>";
    echo "Post: $post <br><br>";

    echo "<b>Basic Pay:</b> ₹$basic <br>";
    echo "<b>HRA:</b> ₹$hra <br>";
    echo "<b>Medical Allowance:</b> ₹$medical <br>";
    echo "<b>Conveyance:</b> ₹$conveyance <br><br>";

    echo "<b>PF:</b> ₹$pf <br>";
    echo "<b>Professional Tax:</b> ₹$pt <br>";
    echo "<b>Leaves Taken:</b> $leaves <br>";
    echo "<b>Leave Deduction:</b> ₹$leave_deduction <br><br>";

    echo "<b>Gross Salary:</b> ₹$gross <br>";
    echo "<b>Total Deductions:</b> ₹$total_deductions <br>";
    echo "<h2>Net Salary: ₹$net_salary</h2>";

    echo "</div>";
}
?>

<br>
<a href="index.php" class="btn">Back to Home</a>

</body>
</html>

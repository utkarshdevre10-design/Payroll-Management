<?php
session_start();
include "config.php";   // must set $conn (mysqli connection)
function getBasicSalary($dept_id, $post_id) {
    $salary_matrix = [
        1 => [1 => 65000, 2 => 45000, 4 => 32000, 5 => 12000],
        2 => [1 => 62000, 3 => 40000, 4 => 30000, 5 => 10000],
        3 => [1 => 60000, 4 => 35000, 5 => 8000],
        4 => [1 => 50000, 3 => 30000, 4 => 28000, 5 => 7000],
        5 => [1 => 65000, 3 => 32000, 4 => 30000, 5 => 9000]
    ];
    return $salary_matrix[$dept_id][$post_id] ?? 0;
}

// 1) figure out logged-in employee id (be flexible)
$empid = null;
if (isset($_SESSION['user']['empid'])) {
    $empid = $_SESSION['user']['empid'];
} elseif (isset($_SESSION['emp_id'])) {
    $empid = $_SESSION['emp_id'];
} elseif (isset($_SESSION['empid'])) {
    $empid = $_SESSION['empid'];
} elseif (isset($_SESSION['user']['id'])) {
    $empid = $_SESSION['user']['id'];
}

// if still no emp id -> redirect to login
if (empty($empid)) {
    header("Location: login.php");
    exit;
}

// fetch employee (with department name & post title for display)
$sql = "SELECT e.emp_id, e.name, e.dept_id, d.dept_name, e.post_id, p.post_title, e.contact, e.doj, e.basic_pay
        FROM employees e
        LEFT JOIN department d ON e.dept_id = d.dept_id
        LEFT JOIN post p ON e.post_id = p.post_id
        WHERE e.emp_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $empid);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($res);

if (!$data) {
    echo "Employee not found.";
    exit;
}

// fetch department list and post list for dropdowns
$dept_q = mysqli_query($conn, "SELECT dept_id, dept_name FROM department ORDER BY dept_id");
$post_q = mysqli_query($conn, "SELECT post_id, post_title FROM post ORDER BY post_id");

// handle POST (update)
$updated = false;
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name      = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    $dept_id   = intval($_POST['dept_id'] ?? 0);
    $post_id   = intval($_POST['post_id'] ?? 0);
    $contact   = mysqli_real_escape_string($conn, trim($_POST['contact'] ?? ''));
    $doj       = mysqli_real_escape_string($conn, trim($_POST['doj'] ?? ''));

    if ($name === '' || $dept_id <= 0 || $post_id <= 0 || $contact === '' || $doj === '') {
        $error = "Please fill all fields correctly.";
    } else {

        // ⭐ Recalculate basic pay based on NEW dept & post
        $basic_pay = getBasicSalary($dept_id, $post_id);

        $u_sql = "UPDATE employees 
                  SET name = ?, dept_id = ?, post_id = ?, contact = ?, doj = ?, basic_pay = ?
                  WHERE emp_id = ?";

        $u_stmt = mysqli_prepare($conn, $u_sql);
        mysqli_stmt_bind_param($u_stmt, 'siissii',
            $name, $dept_id, $post_id, $contact, $doj, $basic_pay, $empid
        );

        if (mysqli_stmt_execute($u_stmt)) {
            $updated = true;

            // refresh data
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, 'i', $empid);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $data = mysqli_fetch_assoc($res);

            // refresh dropdown lists
            $dept_q = mysqli_query($conn, "SELECT dept_id, dept_name FROM department ORDER BY dept_id");
            $post_q = mysqli_query($conn, "SELECT post_id, post_title FROM post ORDER BY post_id");
        } else {
            $error = "Update failed: " . mysqli_error($conn);
        }
    }
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Update Profile</title>
<style>
body { font-family: Arial, Helvetica, sans-serif; background:#f5f7fb; margin:0; padding:20px; }
.container { max-width:420px; margin:30px auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08); }
h2 { margin-top:0; }
label { display:block; font-weight:600; margin-top:12px; }
input[type="text"], input[type="date"], select { width:100%; padding:10px; margin-top:6px; border:1px solid #ccc; border-radius:6px; box-sizing:border-box; }
button { margin-top:16px; width:100%; padding:12px; background:#0077ff; color:#fff; border:none; border-radius:6px; font-size:15px; cursor:pointer; }
.success { background:#e6ffed; border-left:4px solid #2ecc71; padding:10px; border-radius:6px; margin-bottom:12px; }
.error { background:#fff0f0; border-left:4px solid #e74c3c; padding:10px; border-radius:6px; margin-bottom:12px; color:#a94442; }
.info-box { background:#fafafa; padding:12px; border-radius:6px; margin-top:14px; border:1px solid #eee; }
.info-row { margin:8px 0; }
.small { font-size:13px; color:#666; margin-top:6px; }
</style>
</head>
<body>

<div class="container">
    <h2>Update Your Details</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($updated): ?>
        <div class="success">Details updated successfully.</div>
    <?php endif; ?>

    <!-- Update form -->
    <form method="post" autocomplete="off">
        <label>Employee ID (unchangeable)</label>
        <input type="text" value="<?= htmlspecialchars($data['emp_id']) ?>" disabled>

        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($data['name']) ?>" required>

        <label>Department</label>
        <select name="dept_id" required>
            <option value="">-- Select Department --</option>
            <?php
            // rewind dept_q result pointer if needed
            mysqli_data_seek($dept_q, 0);
            while ($d = mysqli_fetch_assoc($dept_q)) {
                $sel = ($d['dept_id'] == $data['dept_id']) ? 'selected' : '';
                echo "<option value=\"{$d['dept_id']}\" $sel>" . htmlspecialchars($d['dept_name']) . "</option>";
            }
            ?>
        </select>

        <label>Post</label>
        <select name="post_id" required>
            <option value="">-- Select Post --</option>
            <?php
            mysqli_data_seek($post_q, 0);
            while ($p = mysqli_fetch_assoc($post_q)) {
                $selp = ($p['post_id'] == $data['post_id']) ? 'selected' : '';
                echo "<option value=\"{$p['post_id']}\" $selp>" . htmlspecialchars($p['post_title']) . "</option>";
            }
            ?>
        </select>

        <label>Contact</label>
        <input type="text" name="contact" value="<?= htmlspecialchars($data['contact']) ?>" required>

        <label>Date of Joining</label>
        <input type="date" name="doj" value="<?= htmlspecialchars($data['doj']) ?>" required>

        <div class="small">Employee values are prefilled. Edit what you want, then click Save Changes.</div>

        <button type="submit">Save Changes</button>
    </form>

    <?php if ($updated): ?>
        <!-- Display updated info (including emp_id) -->
        <div class="info-box">
            <h3>Updated Information</h3>
            <div class="info-row"><strong>Employee ID:</strong> <?= htmlspecialchars($data['emp_id']) ?></div>
            <div class="info-row"><strong>Name:</strong> <?= htmlspecialchars($data['name']) ?></div>
            <div class="info-row"><strong>Department:</strong> <?= htmlspecialchars($data['dept_name']) ?></div>
            <div class="info-row"><strong>Post:</strong> <?= htmlspecialchars($data['post_title']) ?></div>
            <div class="info-row"><strong>Contact:</strong> <?= htmlspecialchars($data['contact']) ?></div>
            <div class="info-row"><strong>Date of Joining:</strong> <?= htmlspecialchars($data['doj']) ?></div>
            <div class="info-row"><strong>Basic Pay:</strong> ₹<?= htmlspecialchars($data['basic_pay']) ?></div>

        </div>

        <button onclick="location.href='index.php'">Back to Dashboard</button>
    <?php endif; ?>

</div>

</body>
</html>

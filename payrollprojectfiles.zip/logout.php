<?php
session_start();

// Destroy all session data
$_SESSION = [];
session_unset();
session_destroy();

// Prevent caching so the browser can't go back
header("Cache-Control: no-cache, must-revalidate");
header("Expires: 0");

// Redirect to login page
header("Location: login.php?logged_out=1");

exit();
?>

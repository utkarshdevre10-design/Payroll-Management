<!DOCTYPE html>
<html>
<head>
<title>Account Deleted</title>
<style>
    body { 
        font-family: Arial; 
        background: #e8ffe8; 
        padding: 40px;
        text-align: center;
    }
    .box {
        background: white; 
        padding: 30px; 
        width: 420px; 
        margin: auto; 
        border-radius: 10px;
        box-shadow: 0 0 10px #9ac79a;
    }
    h2 { color: green; }
    p { font-size: 16px; color: #333; }
    .btn {
        display: inline-block;
        padding: 12px 25px;
        background: #0077ff;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        text-decoration: none;
        margin-top: 20px;
        cursor: pointer;
    }
    .btn:hover {
        background: #005fcc;
    }
</style>
</head>

<body>

<div class="box">
    <h2>✔ Account Deleted Successfully</h2>
    <p>Your employee account and all related records have been removed from the system.</p>

    <a href="login.php" class="btn">Go to Login Page</a>
</div>

</body>
</html>

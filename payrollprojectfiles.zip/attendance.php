<?php

include "config.php";
include "auth.php";
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// If user not logged in → block access
if (!isset($_SESSION['emp_id'])) {
    header("Location: login.php");
    exit;
}

$success = "";
$error = "";

// When form is submitted
if (isset($_POST['save'])) {

    $emp_id = $_SESSION['emp_id']; // employee MUST mark their own attendance
    $month = $_POST['month'];
    $num = $_POST['num_leaves'];

    // Insert attendance
    $sql = "INSERT INTO attendance (emp_id, month_year, num_leaves)
            VALUES (?, ?, ?)";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "isi", $emp_id, $month, $num);

    if (mysqli_stmt_execute($stmt)) {

        // success → show payroll button on index.php
        $_SESSION['attendance_saved'] = true;

        header("Location: index.php");
        exit;

    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Attendance</title>

<style>
body {
    font-family: Arial;
    text-align: center;
    background: #eef2f7;
    padding-top: 40px;
}

.box {
    width: 350px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 0 10px #b8c2d0;
}

input, select {
    width: 90%;
    padding: 10px;
    margin: 12px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
}

button {
    padding: 12px 22px;
    font-size: 16px;
    background: #0077ff;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background: #005fcc;
}

.success { color: green; }
.error { color: red; }
</style>

</head>
<body>

<div class="box">
    <h2>Mark Attendance</h2>

    <?php if($success): ?>
        <p class="success"><?= $success ?></p>
    <?php endif; ?>

    <?php if($error): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">

        <label>Select Month:</label>
        <input type="month" name="month" required>

        <label>No. of Leaves:</label>
        <input type="number" name="num_leaves" min="0" required>

        <button type="submit" name="save">Save Attendance</button>
    </form>
</div>

</body>
</html>
